# Stock Watcher Web App

Upload-ready full-stack stock monitoring app.